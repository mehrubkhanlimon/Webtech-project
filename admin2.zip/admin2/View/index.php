<!DOCTYPE html>
<html>
<head>
    <title>School Management System</title>

    <style>

        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
            text-align: center;
        }
        .navbar {

              background-color: #e6e6fa;                          
             padding: 10px;
            display: flex;
               justify-content: flex-end;
        }
        .navbar a {
            margin-left: 10px;
            text-decoration: none;
            color: #333;
        }
        form {
            margin-top: 50px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        img {
            width: 600px;
            height: 200px;
            margin-bottom: 20px;
        }
        h1 {
            color: #333;
        }
        a.button {
            display: block;
            margin-top: 20px;
            text-decoration: none;
            background-color: #337ab7;
            color: #fff;
            padding: 10px 20px;
            border-radius: 5px;
        }
        a.button:hover {
            background-color: #23527c;
        }
    </style>

    <script>
        function openAdminLogin() {
            window.location.href = "http://localhost/admin2/View/login_view.php";
        }
    </script>
</head>
<body>
    <div class="navbar">
        <a class="button" href="#" onclick="openAdminLogin()">Admin Login</a>
    </div>

    <form>
        <img src="/admin2/Controller/scl.jpg" alt="School Logo">
        <h1>Welcome to School Management System</h1>
    </form>
</body>
</html>
