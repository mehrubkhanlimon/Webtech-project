<!DOCTYPE html>
<html>
<head>
    <title>Registration Form</title>
    <style>
        body {
            background-color: skyblue;
            margin: 0;
            font-family: Arial, sans-serif;
        }
        
        .navbar {
            background-color: #900;
            overflow: hidden;
        }
        
        .navbar a {
            float: left;
            display: block;
            color: white;
            text-align: center;
            padding: 14px 20px;
            text-decoration: none;
        }
        
        .navbar a:hover {
            background-color: #700;
        }
        
        h1 {
            text-align: center;
        }
        
        form {
            margin: 0 auto;
            width: 50%;
            padding: 20px;
            background-color: white;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        
        label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }
        
        input[type="text"] {
            width: calc(100% - 12px);
            padding: 8px;
            margin-bottom: 15px;
            border-radius: 3px;
            border: 1px solid #ccc;
        }
        
        button[type="submit"] {
            background-color: #900;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 3px;
            cursor: pointer;
        }
        
        button[type="submit"]:hover {
            background-color: #700;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <a href="http://localhost/admin2/View/admin_dashboard.php">Dashboard</a>
    </div>
    <h1>Registration Form</h1>
    <form method="get" action="/admin2/Controller/teacher_login_controller.php">
        <label for="id">Id</label>
        <input type="text" name="id"><br><br>

        <label for="name">Name</label>
        <input type="text" name="name" ><br><br>

        <label for="email">Email</label>
        <input type="text" name="email" ><br><br>

        <button type="submit" name="sub" value="register">Registration</button>
    </form>
    
    <script>
         function validateForm() {
            var id = document.getElementById('id').value.trim();
            var name = document.getElementById('name').value.trim();
            var email = document.getElementById('email').value.trim();

            if (id === '' || name === '' || email === '') {
                alert('Please fill in all fields');
                return false;
            }

            return true; 
        }
    </script>
</body>
</html>
