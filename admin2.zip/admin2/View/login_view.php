<!DOCTYPE html>
<html>
<head>
    <title>Admin Login</title>
    <style>
        body {


            background-color: #87ceeb;         
            text-align: center;
        }
        form {


            background-color: #8B0000;
            color: white;
            width: 300px;
            margin: 50px auto;
            padding: 20px;
            border-radius: 10px;
        }

        label {

            display: block;
            margin-bottom: 10px;
            font-weight: bold;

        }

        input[type="text"],
            input[type="password"],

        button {

            width: 100%;
            padding: 8px;
            margin-bottom: 15px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        button {
            background-color: #337ab7;
            color: white;
            font-weight: bold;
            cursor: pointer;
        }
        button:hover {
            background-color: #23527c;
        }
        .error {
            color: white;
        }
        
        .navbar {
            background-color: #333;
            overflow: hidden;
        }
        .navbar a {
            float: left;
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }
       
        .title {
            font-size: 24px;
            margin-bottom: 20px;
        }
    </style>

    <script>
        
       function validateForm() {
            var name = document.getElementById('name').value;
            var pass = document.getElementById('pass').value;

            if (name.trim() === '' || pass.trim() === '') {
                alert('Please fill in all fields');
                return false;
            }
            return true;
        }


    </script>

    
</head>
<body>
    <div class="navbar">
        <a class="active" href="http://localhost/admin2/View/index.php">Home</a>
        
    </div>

    <form action="/admin2/Controller/LoginController.php" method="GET">
        <div class="title">Admin Login</div>

        <label for="name">Name</label>
        <input type="text" name="name" ><br>

        <label for="pass">Password</label>
        <input type="password" name="pass" ><br>

        <button type="submit" name="sub" value="">Login</button>

        <?php
        if (isset($errorMessage)) {
            echo "<p class='error'>$errorMessage</p>";
        }
        ?>
    </form>
</body>
</html>


