<!DOCTYPE html>
<html>
<head>
    <title>Applications</title>
    <style>
        body {
            background-color: skyblue;
            margin: 0;
            font-family: Arial, sans-serif;
        }

        nav {
            background-color: #900;
            color: white;
            padding: 10px 20px;
        }

        nav a {
            color: white;
            text-decoration: none;
            margin-right: 20px;
        }

        nav a:hover {
            text-decoration: underline;
        }

        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
        }

        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #900;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        button {
            padding: 5px 10px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <nav>
        <a href="http://localhost/admin2/View/admin_dashboard.php">Dashboard</a>
    </nav>
    <form method="get" action="/admin2/Controller/view_application_controller.php">
        <table>
            <tr>
                <th>ID</th>
                <th>Application</th>
                <th>Decision</th>
                <th>Approve</th>
                <th>Decline</th>
                <th>Delete</th>
                <th>Name</th>
            </tr>
            <?php 
              $servername = "localhost";
              $username = "root";
              $pass = "";
              $dbname = "test";
              $conn = new mysqli($servername, $username, $pass, $dbname);
             
              $sql = "select * from application";
              $res = mysqli_query($conn, $sql);

              while ($r = mysqli_fetch_assoc($res)) { ?>
                <tr>
                    <td><?php echo $r["Id"]; ?></td>
                    <td><?php echo $r["Application"]; ?></td>
                    <td><?php echo $r["Decision"]; ?></td>
                    <td><button type="submit" name="app" value="<?php echo $r["Id"]; ?>">yes</button></td>
                    <td><button type="submit" name="dec" value="<?php echo $r["Id"]; ?>">no</button></td>
                    <td><button type="submit" name="del" value="<?php echo $r["Id"]; ?>">Delete</button></td>
                    <td><?php echo $r["Name"]; ?></td>
                </tr>
            <?php } ?>
        </table>
    </form>
</body>
</html>
