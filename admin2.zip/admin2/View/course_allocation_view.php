<!DOCTYPE html>
<html>
<head>
    <title>Allocations</title>
    <style>
        
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #87CEEB; 
        }

        .navbar {
            background-color: #8B0000; 
            overflow: hidden;
        }

        .navbar a {
            float: left;
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        .navbar a:hover {
            background-color: #700000;
        }

        form {
            margin-top: 50px; 
        }
    </style>
</head>
<body>
    
    <div class="navbar">
        <a href="http://localhost/admin2/View/admin_dashboard.php">Dashboard</a>
    </div>

    <!-- Content Section -->
    <h2>ALLOCATE COURSES</h2>
    <form action="/admin2/Controller/course_allocation_controller.php" method="post" onsubmit="return confirmSubmit()">
        <label for="teacher">Teacher:</label>
        <select name="teacher" required>
              <?php 
            include_once 'C:/xampp/htdocs/admin2/Controller/course_allocation_controller.php';

            $conn = (new Database())->getConnection();

            $testinfoSql = "SELECT * FROM `testinfo`";
            $testinfoResult = $conn->query($testinfoSql);

            if ($testinfoResult->num_rows > 0) {
                while ($row = $testinfoResult->fetch_assoc()) {
                    echo "<option value='" . $row['Id'] . "'>" . $row['Name'] . "</option>";
                }
            } else {
                echo "<option value=''>No teachers available</option>";
            }
            ?>
        </select><br>

        <label for="course">Course:</label>
        <select name="course" required>
             <?php 
            $coursesSql = "SELECT * FROM `courses`";
            $coursesResult = $conn->query($coursesSql);

            if ($coursesResult->num_rows > 0) {
                while ($row = $coursesResult->fetch_assoc()) {
                    echo "<option value='" . $row['id'] . "'>" . $row['name'] . "</option>";
                }
            } else {
                echo "<option value=''>No courses available</option>";
            }
            ?>
        </select><br>

        <input type="submit" value="Allocate Course"><br><br>

        <a href="http://localhost/admin2/View/admin_dashboard.php">Dashboard</a>
    </form>

    <script>
        function confirmSubmit() {
            return confirm("Are you sure you want to allocate this course?");
        }
    </script>
</body>
</html>
