<!DOCTYPE html>
<html>
<head>
    <title>Allocated Courses</title>
    <style>
        body {
            background-color: skyblue;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .navbar {
            background-color: #800020; 
            color: white;
            overflow: hidden;
        }

        .navbar a {
            float: left;
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        .navbar a:hover {
            background-color: #ddd;
            color: black;
        }

        table {
            border-collapse: collapse;
            width: 80%;
            margin: 20px auto;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <a href="http://localhost/admin2/View/admin_dashboard.php">Dashboard</a>
    </div>
    <form method="get" action="/admin2/Controller/allocated_courses_controller.php">
        <table border="1">
            <tr>
                <th>id</th>
                <th>teacher_id</th>
                <th>course_id</th>
                <th>Action</th>
            </tr>

            <?php
                $servername = "localhost";
                $username = "root";
                $pass = "";
                $dbname = "test";
                $conn = new mysqli($servername, $username, $pass, $dbname);

                $sql = "SELECT * FROM `allocations`";
                $res = mysqli_query($conn, $sql);
                while ($r = mysqli_fetch_assoc($res)) { ?>
                    <tr>
                        <td><?php echo $r["id"]; ?></td>
                        <td><?php echo $r["teacher_id"]; ?></td>
                        <td><?php echo $r["course_id"]; ?></td>
                        <td><button type="submit" name="del" value="<?php echo $r["id"]; ?>">Delete</button></td>
                    </tr>
            <?php } ?>
        </table>
        
    </form>
</body>
</html>
