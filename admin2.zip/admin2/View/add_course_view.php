<!DOCTYPE html>
<html>
<head>
    <title>ADD COURSE</title>
    <style>
        body {
            background-color: skyblue;
        }
        .navbar {
            background-color: #800000; /* Red wine color */
            padding: 10px;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .navbar a {
            color: white;
            text-decoration: none;
            margin-right: 20px;
        }
        .form-container {
            margin-top: 50px;
            padding: 20px;
            width: 50%;
            margin-left: auto;
            margin-right: auto;
            background-color: white;
            border-radius: 10px;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <div>
            <a href="http://localhost/admin2/View/admin_dashboard.php">Dashboard</a>
        </div>
    </div>

    <div class="form-container">
        <h1>Registration Form</h1>
        <form method="get" action="/admin2/Controller/add_course_controller.php" onsubmit="return validateForm()">
            <label for="id">id</label>
            <input type="text" name="id" id="id" ><br><br>

            <label for="name">name</label>
            <input type="text" name="name" id="name" ><br><br>

            <button type="submit" name="sub" value="">ADD</button>
        </form>
        <?php if (isset($result)) {
            echo $result;
        } ?>
    </div>

    <script>
        function validateForm() {
            var id = document.getElementById('id').value;
            var name = document.getElementById('name').value;

            if (id.trim() === '' || name.trim() === '') {
                alert('Please fill in all fields');
                return false;
            }
            return true;
        }
    </script>
</body>
</html>
