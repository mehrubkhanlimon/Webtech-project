<!DOCTYPE html>
<html>
<head>
    <title>Routine</title>
    <style>
        body {
            background-color: skyblue;
            font-family: Arial, sans-serif;
            margin: 0;
        }

        .navbar {
            background-color: #800000; 
            overflow: hidden;
        }

        .navbar a {
            float: left;
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        .navbar a:hover {
            background-color: #ddd;
            color: black;
        }

        h2 {
            text-align: center;
        }

        form {
            text-align: center;
        }

        table {
            margin: 20px auto;
            border-collapse: collapse;
            width: 80%;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }
    </style>
    <script>
        
    </script>
</head>
<body>

<div class="navbar">
    <a href="http://localhost/admin2/View/admin_dashboard.php">Dashboard</a>
</div>

<h2>Routine Management</h2>

<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
    <label for="subject">Subject</label>
    <input type="text" name="subject" ><br><br>

    <label for="day">Day</label>
    <input type="text" name="day" ><br><br>

    <label for="time">Time</label>
    <input type="text" name="time" ><br><br>

    <input type="submit" name="addroutine" value="Add Routine">
</form>
<hr>

<h3>Routine Table</h3>
<table border="1">
    <tr>
        <th>Subject</th>
        <th>Day</th>
        <th>Time</th>
        <th>Actions</th>
    </tr>

    <?php 
    include_once 'C:/xampp/htdocs/admin2/Controller/routine_controller.php';

    $result = $routineController->getAllRoutines();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) { ?>
            <tr>
                <td><?php echo $row["subject"]; ?></td>
                <td><?php echo $row["day"]; ?></td>
                <td><?php echo $row["time"]; ?></td>
                <td>
                    <form method="post" style="margin: 0;">
                        <button type="submit" name="delete" value="<?php echo $row["id"]; ?>">Delete</button>
                    </form>
                </td>
            </tr>
        <?php }
    } else {
        echo "<tr><td colspan='4'>No routines found</td></tr>";
    }
    ?>
</table>

</body>
</html>
