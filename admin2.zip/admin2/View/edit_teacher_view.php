<!DOCTYPE html>
<html>
<head>
    <title>TEACHER EDIT</title>
    <style>
        body {
            background-color: skyblue;
            margin: 0;
            font-family: Arial, sans-serif;
        }

        .navbar {
            background-color: darkred;
            overflow: hidden;
        }

        .navbar a {
            float: left;
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }

        .navbar a:hover {
            background-color: maroon;
        }

        table {
            border-collapse: collapse;
            width: 80%;
            margin: 20px auto;
        }

        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: maroon;
            color: white;
        }

        button {
            padding: 5px 10px;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <a href="http://localhost/admin2/View/admin_dashboard.php">Dashboard</a>
    </div>

    <form method="get" action="/admin2/Controller/edit_teacher_controller.php">
        <table border="1">
            <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Email</th>
                <th>Salary</th>
                <th>Option</th>
                <th>Option</th>
            </tr>
            <?php
            $servername = "localhost";
            $username = "root";
            $pass = "";
            $dbname = "test";
            $conn = new mysqli($servername, $username, $pass, $dbname);
            $sql = "SELECT * FROM `testinfo`";
            $res = mysqli_query($conn, $sql);
            while ($r = mysqli_fetch_assoc($res)) { ?>
                <tr>
                    <td><?php echo $r["Id"]; ?></td>
                    <td><?php echo $r["Name"]; ?></td>
                    <td><?php echo $r["Email"]; ?></td>
                    <td><?php echo $r["salary"]; ?></td>
                    <td><button type="submit" name="edit" value="<?php echo $r["Id"]; ?>">Edit</button></td>
                    <td><button type="submit" name="del" value="<?php echo $r["Id"]; ?>">Delete</button></td>
                </tr>
            <?php } ?>
        </table>
    </form>
</body>
</html>
