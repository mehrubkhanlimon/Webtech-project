<!DOCTYPE html>
<html>
<head>
    <title>DASHBOARD</title>
    <style>
        body {

            font-family: Arial, sans-serif;
            background-color: #87ceeb;
            margin: 0;
            padding: 0;
            text-align: center;

        }
        img {

            width: 600px;
            height: 200px;
            display: block;
            margin: 0 auto 40px; 
        }

        .button-box {

            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 20px;
            margin-bottom: 30px;
        }

        .button-box a {

            display: inline-block;
            text-decoration: none;
            color: #333;
            background-color: #e6e6fa;
            padding: 15px 30px;
            border-radius: 10px;
            width: 250px;
            margin-bottom: 20px;
        }

        .logout {
            background-color: #800000; 
            color: #fff;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
        }

    </style>

    <script>
        function openAdminLogin() {
            window.location.href = "http://localhost/admin2/View/login_view.php";
        }
    </script>


</head>

<body>
    <img src="/admin2/Controller/SCHOOL.jpg" alt="School Image">

    <div class="button-box">
        <a href="http://localhost/admin2/View/teacher_login_view.php">TEACHER REGISTRATION</a>
        <a href="http://localhost/admin2/View/edit_teacher_view.php">VIEW TEACHER</a>
        <a href="http://localhost/admin2/View/application.php">APPLICATION</a>
        <a href="http://localhost/admin2/View/course_allocation_view.php">COURSE MANAGEMENT</a>
        <a href="http://localhost/admin2/View/add_course_view.php">ADD COURSE</a>
        <a href="http://localhost/admin2/View/allocated_courses_view.php">ALLOCATED COURSE</a>
        
        <a href="http://localhost/admin2/View/salary_view.php">SALARY</a>
        <a href="http://localhost/admin2/View/routine_view.php">ROUTINE</a>
    </div>


    <div class="navbar">
        <a class="logout" href="http://localhost/admin2/View/login_view.php">Logout</a>
    </div>


</body>

</html>
