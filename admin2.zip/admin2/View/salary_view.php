<!DOCTYPE html>
<html>
<head>
    <title>SALARY</title>
    <style>
        body {
            background-color: skyblue;
            font-family: Arial, sans-serif;
            margin: 0;
        }

        .navbar {
            background-color: #800020; 
            color: white;
            padding: 15px;
        }

        .container {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        form {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 10px;
        }

        input[type="text"],
        input[type="submit"] {
            padding: 8px;
            margin-bottom: 15px;
            width: 200px;
            border-radius: 4px;
            border: 1px solid #ccc;
        }

        input[type="submit"] {
            background-color: #800020;
            color: white;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <a href="http://localhost/admin2/View/admin_dashboard.php">Dashboard</a>
    </div>

    <div class="container">
        <h2>Insert Teacher Salary</h2>
        <form action="/admin2/Controller/salary_controller.php" method="post">
            <label for="teacher_id">Teacher ID:</label>
            <input type="text" id="teacher_id" name="teacher_id" required><br><br>

            <label for="salary">Salary:</label>
            <input type="text" id="salary" name="salary" required><br><br>

            <input type="submit" value="Insert Salary"><br>
        </form>
    </div>
    <script>
        function validateForm() {
            var teacherId = document.getElementById("teacher_id").value;
            var salary = document.getElementById("salary").value;

            if (teacherId === '' || salary === '') {
                alert("Please fill in all fields.");
                return false;
            }

           

            return true;
        }
    </script>
</body>
</html>
