<!DOCTYPE html>
<html>
<head>
    <title>applications</title>
</head>
<body>
 <form method="get" action="/admin2/Controller/view_application_controller.php">
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Application</th>
       <th>Decision</th>
      <th>Approve</th>
      <th>DECLINE</th>
      <th>DELET</th>
       <th>Name</th>
        </tr>
        <?php while($r = mysqli_fetch_assoc($res)) { ?>
            <tr>
                <td><?php echo $r["Id"] ; ?></td>
      <td><?php echo $r["Application"] ; ?></td>
        <td><?php echo $r["Decision"] ; ?></td>
      <td><button type="submit" name="app" value="<?php  echo $r["Id"] ; ?>">yes</button>  </td> 

      
       <td><button type="submit" name="dec" value="<?php  echo $r["Id"] ; ?>">no</button>   </td>
        <td><button type="submit" name="del" value="<?php echo $r["Id"] ; ?>">Delete</button>   </td>
      
         <td><?php echo $r["Name"] ; ?></td>
            </tr>
        <?php } ?>
    </table>
   <a href="http://localhost/admin2/View/admin_dashboard.php">Dashboard</a>
</form>
</body>
</html>

