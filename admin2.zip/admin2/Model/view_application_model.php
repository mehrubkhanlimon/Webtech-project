<?php
class Model {
    protected $conn;

    public function __construct() {
        $servername = "localhost";
        $username = "root";
        $pass = "";
        $dbname = "test";
        $this->conn = new mysqli($servername, $username, $pass, $dbname);
    }

    public function getConnection() {
        return $this->conn;
    }

    public function approveApplication($id) {
        $conn = $this->getConnection();
        $sql1 = "UPDATE `application` SET `Decision`='approved' WHERE `id`='$id'";
        mysqli_query($conn, $sql1);
    }

    public function declineApplication($id) {
        $conn = $this->getConnection();
        $sql1 = "UPDATE `application` SET `Decision`='declined' WHERE `id`='$id'";
        mysqli_query($conn, $sql1);
    }

    public function deleteApplication($id) {
        $conn = $this->getConnection();
        $sql1 = "DELETE FROM `application` WHERE `id`='$id'";
        mysqli_query($conn, $sql1);
    }

    public function getAllApplications() {
        $conn = $this->getConnection();
        $sql = "SELECT * FROM `application`";
        $res = mysqli_query($conn, $sql);
        return $res;
    }
}
?>

