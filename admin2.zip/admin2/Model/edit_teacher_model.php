<?php
class Model {
    protected $conn;

    public function __construct() {
        $servername = "localhost";
        $username = "root";
        $pass = "";
        $dbname = "test";
        $this->conn = new mysqli($servername, $username, $pass, $dbname);
    }

    public function getConnection() {
        return $this->conn;
    }
}
?>

