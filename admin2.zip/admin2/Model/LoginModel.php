<?php
class LoginModel {
    private $conn;

    public function __construct() {
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "test";

        $this->conn = new mysqli($servername, $username, $password, $dbname);
    }

    public function validateUser($name, $pass) {
        $name = $this->conn->real_escape_string($name);
        $pass = $this->conn->real_escape_string($pass);

        $sql = "SELECT * FROM `adminlog` WHERE `Name`='$name' AND `Password`='$pass'";
        $res = $this->conn->query($sql);

        if ($res->num_rows > 0) {
            while ($r = $res->fetch_assoc()) {
                $_SESSION['name'] = $r["Name"];
                $_SESSION['pass'] = $r["Password"];
                return true;
            }
        }
        return false;
    }
}
?>