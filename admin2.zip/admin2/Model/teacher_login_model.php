<?php
class Model {
    private $conn;

    public function __construct() {
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "test";

        $this->conn = new mysqli($servername, $username, $password, $dbname);
    }

    public function checkIdExists($id) {
        $checkSql = "SELECT * FROM `testinfo` WHERE `Id` = '$id'";
        $checkResult = $this->conn->query($checkSql);

        return ($checkResult !== false && $checkResult->num_rows > 0);
    }

    public function insertData($id, $name, $email) {
        $sql1 = "INSERT INTO `testinfo` (`Id`, `Name`, `Email`) VALUES ('$id', '$name', '$email')";
        return $this->conn->query($sql1);
    }
}
?>

