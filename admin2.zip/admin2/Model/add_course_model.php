<?php
class Model {
    protected $conn;

    public function __construct() {
        $servername = "localhost";
        $username = "root";
        $pass = "";
        $dbname = "test";
        $this->conn = new mysqli($servername, $username, $pass, $dbname);
    }

    public function getConnection() {
        return $this->conn;
    }

    public function addCourse($id, $name) {
        $conn = $this->getConnection();

        $checkSql = "SELECT * FROM `courses` WHERE `id` = '$id'";
        $checkResult = mysqli_query($conn, $checkSql);

        if ($checkResult !== false && mysqli_num_rows($checkResult) > 0) {
            return "ID already exists, please choose another ID.";
        } else {
            $sql = "INSERT INTO `courses` (`id`, `name`) VALUES ('$id', '$name')";
            mysqli_query($conn, $sql);
            return "Course added successfully.";
        }
    }
}
?>
