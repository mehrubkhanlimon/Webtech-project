<?php
class Model {
    protected $conn;

    public function __construct() {
        $servername = "localhost";
        $username = "root";
        $pass = "";
        $dbname = "test";
        $this->conn = new mysqli($servername, $username, $pass, $dbname);
    }

    public function getConnection() {
        return $this->conn;
    }

    public function deleteAllocation($id) {
        $conn = $this->getConnection();
        $sql1 = "DELETE FROM `allocations` WHERE `id`='$id'";
        mysqli_query($conn, $sql1);
    }

    public function getAllAllocations() {
        $conn = $this->getConnection();
        $sql = "SELECT * FROM `allocations`";
        $res = $conn->query($sql);
        return $res;
    }
}
?>
