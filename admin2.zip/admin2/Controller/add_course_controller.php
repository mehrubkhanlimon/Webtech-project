<?php
include_once 'C:/xampp/htdocs/admin2/Model/add_course_model.php';

class Controller {
    private $model;

    public function __construct() {
        $this->model = new Model();
    }

    public function processRequest() {
        if (isset($_GET['sub'])) {
            $id = $_GET['id'];
            $name = $_GET['name'];

           
            if (empty($id) || empty($name)) {
               
                $error = "Please fill in all fields.";
                include 'C:/xampp/htdocs/admin2/View/add_course_view.php';
                return; 
            }

            $result = $this->model->addCourse($id, $name);
          
            include 'C:/xampp/htdocs/admin2/View/add_course_view.php';
        } else {
            
        }
    }
}

$controller = new Controller();
$controller->processRequest();
?>
