<?php
session_start(); 


include_once 'C:/xampp/htdocs/admin2/Model/LoginModel.php';


if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['sub'])) 

{
    if (empty($_GET['name']) || empty($_GET['pass'])) {
        $errorMessage = "Please fill in all fields.";
    } 

    else

     {
        $loginModel = new LoginModel();

        $name = $_GET['name'];
        $pass = $_GET['pass'];

        $loginResult = $loginModel->validateUser($name, $pass);

        if ($loginResult) {
            header("location: /admin2/View/admin_dashboard.php");
            exit();
        } else {
            $errorMessage = "Invalid User";
        }
    }
}



include_once 'C:/xampp/htdocs/admin2/View/login_view.php';
?>
