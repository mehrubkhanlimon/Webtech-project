<?php
session_start(); // Starting the session

include_once 'C:/xampp/htdocs/admin2/Model/teacher_login_model.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['sub']) && $_GET['sub'] === 'register') {
    $model = new Model();

    // Validate input fields
    if (empty($_GET['id']) || empty($_GET['name']) || empty($_GET['email'])) {
        echo "Please fill in all fields.";
    } else {
        $id = $_GET['id'];
        $name = $_GET['name'];
        $email = $_GET['email'];

        $idExists = $model->checkIdExists($id);

        if ($idExists) {
            echo "ID already exists, please choose another ID.";
        } else {
            $inserted = $model->insertData($id, $name, $email);
            if ($inserted) {
                echo "Successfully registered!";
            } else {
                echo "Registration failed!";
            }
        }
    }
}

include_once 'C:/xampp/htdocs/admin2/View/teacher_login_view.php';
?>
