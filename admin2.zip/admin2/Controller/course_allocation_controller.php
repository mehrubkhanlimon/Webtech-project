<?php
include_once 'C:/xampp/htdocs/admin2/Model/course_allocation_model.php';

class AllocationController {
    private $db;

    public function __construct() {
        $this->db = new Database();
    }

    public function allocateCourse($teacherId, $courseId) {
        $conn = $this->db->getConnection();

        $teacherId = $conn->real_escape_string($teacherId);
        $courseId = $conn->real_escape_string($courseId);

        $checkSql = "SELECT * FROM `allocations` WHERE `teacher_id` = $teacherId AND `course_id` = $courseId";
        $checkResult = $conn->query($checkSql);

        if ($checkResult->num_rows == 0) {
            $allocationSql = "INSERT INTO `allocations` (`teacher_id`, `course_id`) VALUES ($teacherId, $courseId)";
            if ($conn->query($allocationSql) == TRUE) {
                return "Course allocated";
            } else {
                return "Error: " . $conn->error;
            }
        } else {
            return "Course already allocated";
        }
    }
}

include_once 'C:/xampp/htdocs/admin2/View/course_allocation_view.php';

$allocationController = new AllocationController();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['teacher']) && isset($_POST['course'])) {
        $result = $allocationController->allocateCourse($_POST['teacher'], $_POST['course']);
        echo $result;
    }
}
?>
