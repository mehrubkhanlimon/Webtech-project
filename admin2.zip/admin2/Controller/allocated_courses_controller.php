
<?php
include_once 'C:/xampp/htdocs/admin2/Model/allocated_courses_model.php';
class Controller {
    private $model;

    public function __construct() {
        $this->model = new Model();
    }

    public function processRequest() {
        if (isset($_GET['del'])) {
            $id = $_GET['del'];
            $this->model->deleteAllocation($id);
        }

        $allocations = $this->model->getAllAllocations();
        include 'C:/xampp/htdocs/admin2/View/allocated_courses_view.php';
    }
}

$controller = new Controller();
$controller->processRequest();
?>