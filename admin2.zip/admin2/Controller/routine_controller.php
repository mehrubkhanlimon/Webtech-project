<?php
include_once 'C:/xampp/htdocs/admin2/Model/routine_model.php';

class RoutineController {
    private $db;

    public function __construct() {
        $this->db = new Database();
    }

    public function addRoutine($subject, $day, $time) {
        $conn = $this->db->getConnection();

        $subject = $conn->real_escape_string($subject);
        $day = $conn->real_escape_string($day);
        $time = $conn->real_escape_string($time);

        $sql = "INSERT INTO `routines` (`subject`, `day`, `time`) VALUES ('$subject', '$day', '$time')";

        if ($conn->query($sql) === TRUE) {
            header("Location: {$_SERVER['PHP_SELF']}");
            exit();
        } else {
            return "Error: " . $sql . "<br>" . $conn->error;
        }
    }

    public function deleteRoutine($id) {
        $conn = $this->db->getConnection();

        $id = $conn->real_escape_string($id);

        $sql = "DELETE FROM `routines` WHERE `id`='$id'";
        if ($conn->query($sql) === TRUE) {
            header("Location: {$_SERVER['PHP_SELF']}");
            exit();
        } else {
            return "Error: " . $sql . "<br>" . $conn->error;
        }
    }

    public function getAllRoutines() {
        $conn = $this->db->getConnection();

        $sql = "SELECT * FROM `routines`";
        $result = $conn->query($sql);

        return $result;
    }
}

include_once 'C:/xampp/htdocs/admin2/View/routine_view.php';

$routineController = new RoutineController();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['addroutine'])) {
        $subject = $_POST['subject'];
        $day = $_POST['day'];
        $time = $_POST['time'];

        if (empty($subject) || empty($day) || empty($time)) {
            echo "Please fill in all fields.";
        } else {
            $result = $routineController->addRoutine($subject, $day, $time);
            echo $result;
        }
    }

    if (isset($_POST['delete'])) {
        $result = $routineController->deleteRoutine($_POST['delete']);
        echo $result;
    }
}
?>
