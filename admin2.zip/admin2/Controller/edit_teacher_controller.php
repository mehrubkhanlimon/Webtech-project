

<?php
include_once 'C:/xampp/htdocs/admin2/Model/edit_teacher_model.php';

class Controller {
    private $model;

    public function __construct() {
        $this->model = new Model();
    }

    public function handleRequest() {
        $conn = $this->model->getConnection();

        if (isset($_GET['del'])) {
            $id = $_GET['del'];
             $sql1 = "DELETE FROM `testinfo` WHERE `id`='$id'";
          echo "DELETED";

            mysqli_query($conn, $sql1);
        } else if (isset($_GET['edit'])) {
            echo $_GET['edit'];
            echo " no id can change";
        }

       $sql = "SELECT * FROM `testinfo`";
        $res = mysqli_query($conn, $sql);

        include 'C:/xampp/htdocs/admin2/View/edit_teacher_view.php'; 
    }
}

$controller = new Controller();
$controller->handleRequest();
?>
