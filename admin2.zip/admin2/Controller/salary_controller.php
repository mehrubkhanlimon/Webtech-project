<?php
include_once 'C:/xampp/htdocs/admin2/Model/salary_model.php';

class Controller {
    private $db;

    public function __construct() {
        $this->db = new Database();
    }

    public function updateSalary($teacher_id, $salary) {
        $conn = $this->db->getConnection();

        $teacher_id = $conn->real_escape_string($teacher_id);
        $salary = $conn->real_escape_string($salary);

        $updateSql = "UPDATE `testinfo` SET `salary` = '$salary' WHERE `id` = '$teacher_id'";
          
        if ($conn->query($updateSql) === TRUE) {
            return "Salary updated successfully";
        } else {
            return "Error updating salary: " . $conn->error;
        }
    }
}

include_once 'C:/xampp/htdocs/admin2/View/salary_view.php';

$controller = new Controller();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $result = $controller->updateSalary($_POST["teacher_id"], $_POST["salary"]);
    echo $result;
}
?>

