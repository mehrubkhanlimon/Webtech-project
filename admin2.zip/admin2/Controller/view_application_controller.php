

<?php
include_once 'C:/xampp/htdocs/admin2/Model/view_application_model.php';

class Controller {
    private $model;

    public function __construct() {
        $this->model = new Model();
    }

    public function processRequest() {
        if (isset($_GET['app'])) {
            $id = $_GET['app'];
            $this->model->approveApplication($id);
        } elseif (isset($_GET['dec'])) {
            $id = $_GET['dec'];
            $this->model->declineApplication($id);
        } elseif (isset($_GET['del'])) {
            $id = $_GET['del'];
            $this->model->deleteApplication($id);
        }

        $application = $this->model->getAllApplications();
        include 'C:/xampp/htdocs/admin2/View/application.php';
    }
}

$controller = new Controller();
$controller->processRequest();
?>
